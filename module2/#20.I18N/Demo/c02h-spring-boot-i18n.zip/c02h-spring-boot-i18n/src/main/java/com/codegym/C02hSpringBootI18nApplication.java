package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C02hSpringBootI18nApplication {

    public static void main(String[] args) {
        SpringApplication.run(C02hSpringBootI18nApplication.class, args);
    }

}
