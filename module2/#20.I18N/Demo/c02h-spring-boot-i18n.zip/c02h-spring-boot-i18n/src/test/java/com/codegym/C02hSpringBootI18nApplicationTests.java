package com.codegym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C02hSpringBootI18nApplicationTests {

    @Test
    void contextLoads() {
    }

}
