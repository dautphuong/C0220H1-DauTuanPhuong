package com.example.demo.dto;

import java.util.ArrayDeque;

@SuppressWarnings("serial")
public class TodoList extends ArrayDeque<TodoItem>{

}
