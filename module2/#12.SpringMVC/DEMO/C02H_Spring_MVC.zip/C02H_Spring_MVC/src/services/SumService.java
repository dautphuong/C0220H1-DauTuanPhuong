package services;

public interface SumService {
    double sum(double a, double b);
}
