package com.codegym.services;

import com.codegym.models.User;

public interface UserService {
    void save(User user);
}
