package com.rhysnguyen.casestudyjavaweb.service;

import java.util.List;

import com.rhysnguyen.casestudyjavaweb.entity.RentType;

public interface RentTypeService {

    List<RentType> findAll();
    
}