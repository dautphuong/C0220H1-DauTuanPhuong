# Trivia-Game
A trivia game with countdown timer.
