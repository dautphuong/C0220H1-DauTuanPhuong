package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class EmployeeWorkingDAO {
	PreparedStatement pst;
	ResultSet rs;
	Statement st;
	Connection conn;
}
