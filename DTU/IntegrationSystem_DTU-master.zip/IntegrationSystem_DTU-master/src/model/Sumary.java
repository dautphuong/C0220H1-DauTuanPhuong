package model;

public class Sumary {
	private int value;
	
}
