package constant;

public class CommonConstant {
	public static final String DIR_UPLOAD ="files";
	public static final String SUCCESS="SUCCESS";
	public static final String ADDSUCCESS="ADDSUCCESS";
	public static final String EDITSUCCESS="EDITSUCCESS";
	public static final String DELSUCCESS="DELSUCCESS";
	public static final String ERROR="ERROR";
	public static final String DOUBLECAT="DOUBLECAT";
	public static final String NORESULT="NORESULT";
	public static String FACEBOOK_APP_ID = "210350843369140";
	public static String FACEBOOK_APP_SECRET = "c1143734d9618dead6550168973a6c0a";
	public static String FACEBOOK_REDIRECT_URL = "https://localhost:8094/login-facebook";
	public static String FACEBOOK_LINK_GET_TOKEN = "https://graph.facebook.com/oauth/access_token?client_id=%s&client_secret=%s&redirect_uri=%s&code=%s";

}
