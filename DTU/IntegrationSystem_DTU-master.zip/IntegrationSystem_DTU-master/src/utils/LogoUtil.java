package utils;

public class LogoUtil {
	public static String logo="";
}
