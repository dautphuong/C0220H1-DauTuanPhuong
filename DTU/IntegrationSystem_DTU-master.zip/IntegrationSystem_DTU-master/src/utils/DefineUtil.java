package utils;

public class DefineUtil {
	public static final int NUMBER_PER_PAGE = 3;
	public static final int NUMBER_PER_PAGE_USER = 5;
	public static final int NUMBER_PER_PAGE_CONTACT = 10;
	public static final int NUMBER_PER_PAGE_Comment = 10;
	public static final int NUMBER_PER_PAGE_Contact = 10;
	public static final String SUCCESS ="SUCCESS";
}
